(function () {

  // -----------------------------------------------
  // 1. Traduções PT-BR
  // -----------------------------------------------
  const traducoes = {
    "January":   "JAN",
    "February":  "FEV",
    "March":     "MAR",
    "April":     "ABR",
    "May":       "MAI",
    "June":      "JUN",
    "July":      "JUL",
    "August":    "AGO",
    "September": "SET",
    "October":   "OUT",
    "November":  "NOV",
    "December":  "DEZ",
    "Sun": "dom", "Mon": "seg", "Tue": "ter",
    "Wed": "qua", "Thu": "qui", "Fri": "sex", "Sat": "sáb"
  };

  // nomes PT para comparação (índice = getMonth())
  const nomesMes = [
    "JAN","FEV","MAR","ABR","MAI","JUN",
    "JUL","AGO","SET","OUT","NOV","DEZ"
  ];

  function traduzir(texto) {
    let s = texto;
    Object.keys(traducoes).forEach(function (k) {
      s = s.replace(new RegExp("\\b" + k + "\\b", "g"), traducoes[k]);
    });
    return s;
  }

  // -----------------------------------------------
  // 2. Semana ISO
  // -----------------------------------------------
  function isoWeek(d) {
    const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    t.setUTCDate(t.getUTCDate() + 4 - (t.getUTCDay() || 7));
    const jan1 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
    return Math.ceil((((t - jan1) / 86400000) + 1) / 7);
  }

  const hoje       = new Date();
  const semAtual   = isoWeek(hoje);
  const mesAtual   = hoje.getMonth();   // 0-based
  const anoAtual   = hoje.getFullYear();

  // -----------------------------------------------
  // 3. Processar cabeçalhos
  // -----------------------------------------------
  function processar() {

    /* --- linha primária: mês / ano --- */
    document.querySelectorAll(".rct-dateHeader-primary").forEach(function (el) {
      // O formato Moment é "MMMM YYYY" → chega como "March⏎2026"
      let txt = el.textContent || "";
      txt = traduzir(txt);
      txt = txt.replace(/⏎/g, "\n").replace(/\\n/g, "\n");

      if (el.textContent !== txt) el.textContent = txt;

      // destaque do mês atual
      const partes   = txt.split("\n");
      const nomeMes  = (partes[0] || "").trim().toLowerCase();
      const anoStr   = parseInt((partes[1] || "").trim(), 10);
      const ehAtual  = (nomeMes === nomesMes[mesAtual] && anoStr === anoAtual);

      el.classList.toggle("mes-atual", ehAtual);
    });

    /* --- linha secundária: semana (número) ou dia (visão detalhada) --- */
    document.querySelectorAll(".rct-dateHeader:not(.rct-dateHeader-primary)").forEach(function (el) {
      let txt = (el.textContent || "").trim();

      // traduz dias da semana (visão diária)
      const trad = traduzir(txt);
      if (txt !== trad) { el.textContent = trad; txt = trad; }

      // destaque: só quando é número puro (= visão de semanas)
      const num = parseInt(txt, 10);
      const numTxt = txt.replace(/[^\d]/g, ""); // remove tudo que não é número
      const ehSemAtual = (numTxt !== "" && parseInt(numTxt, 10) === semAtual);      el.classList.toggle("semana-atual", ehSemAtual);
      if (el.parentElement) el.parentElement.classList.toggle("semana-atual-col", ehSemAtual);
    });
  }

  // -----------------------------------------------
  // 4. Observer
  // -----------------------------------------------
  function iniciar() {
    processar();
    const obs = new MutationObserver(processar);
    obs.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  window.addEventListener("load", iniciar);

})();
